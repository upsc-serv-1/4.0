import { Stack } from 'expo-router';

export default function NotesLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
        animationDuration: 350,
        gestureEnabled: true,
        fullScreenGestureEnabled: false,
      }}
    >
      <Stack.Screen name="index" />
      <Stack.Screen name="editor" options={{ animation: 'slide_from_right', animationDuration: 280 }} />
      <Stack.Screen name="pro-editor" options={{ animation: 'slide_from_bottom', animationDuration: 320 }} />
    </Stack>
  );
}
